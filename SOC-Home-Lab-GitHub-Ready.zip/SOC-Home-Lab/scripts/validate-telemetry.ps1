# Run from an elevated PowerShell session when Sysmon is installed.
# Displays recent examples of key telemetry used in this lab.

$sysmonLog = 'Microsoft-Windows-Sysmon/Operational'

Write-Host "`n=== Event ID 1: Process Create ==="
Get-WinEvent -FilterHashtable @{ LogName=$sysmonLog; Id=1 } -MaxEvents 3 |
    Format-List TimeCreated, Id, Message

Write-Host "`n=== Event ID 3: Network Connection ==="
Get-WinEvent -FilterHashtable @{ LogName=$sysmonLog; Id=3 } -MaxEvents 3 |
    Format-List TimeCreated, Id, Message

Write-Host "`n=== Event ID 11: File Create ==="
Get-WinEvent -FilterHashtable @{ LogName=$sysmonLog; Id=11 } -MaxEvents 3 |
    Format-List TimeCreated, Id, Message

Write-Host "`n=== Event ID 22: DNS Query ==="
Get-WinEvent -FilterHashtable @{ LogName=$sysmonLog; Id=22 } -MaxEvents 3 |
    Format-List TimeCreated, Id, Message

Write-Host "`n=== PowerShell Event ID 4104 ==="
Get-WinEvent -FilterHashtable @{
    LogName='Microsoft-Windows-PowerShell/Operational'
    Id=4104
} -MaxEvents 3 | Format-List TimeCreated, Id, Message

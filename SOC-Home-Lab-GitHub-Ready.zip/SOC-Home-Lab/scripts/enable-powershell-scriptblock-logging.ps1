# Run from an elevated PowerShell session.
# Enables PowerShell Script Block Logging (Event ID 4104).

$path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging"

New-Item -Path $path -Force | Out-Null
Set-ItemProperty -Path $path -Name EnableScriptBlockLogging -Value 1

Get-ItemProperty $path | Select-Object EnableScriptBlockLogging

Get-WinEvent -ListLog "Microsoft-Windows-PowerShell/Operational" |
    Select-Object LogName, IsEnabled, RecordCount

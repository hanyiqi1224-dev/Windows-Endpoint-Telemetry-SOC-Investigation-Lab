# SOC Investigation #001 — PowerShell DNS, HTTPS, and File Creation

## Objective

Practice correlating multiple endpoint telemetry sources to reconstruct a small sequence of controlled activity.

## Controlled Activity

```powershell
Resolve-DnsName example.com
Invoke-WebRequest https://example.com -Method Head
"Mini SOC Investigation" | Set-Content "$env:TEMP\soc-lab-test-final.txt"
```

## Evidence

### 1. DNS Query — Sysmon Event ID 22

- Process: `powershell.exe`
- Query: `example.com`
- Query status: `0` (successful)
- Returned addresses included:
  - `172.66.147.243`
  - `104.20.23.154`

![DNS Query](../screenshots/05-event22-dns-query.png)

### 2. Network Connection — Sysmon Event ID 3

- Process: `powershell.exe`
- Protocol: TCP
- Initiated: `true`
- Destination: `172.66.147.243:443`
- Service: HTTPS

![Network Connection](../screenshots/07-event3-network-connection.png)

### 3. File Creation — Sysmon Event ID 11

- Process: `powershell.exe`
- Target file: `%TEMP%\soc-lab-test-final.txt`

![File Creation](../screenshots/06-event11-file-create.png)

## Correlation Method

The events shared the same Sysmon `ProcessGuid` and `ProcessId`, allowing the DNS query, outbound network connection, and file creation to be attributed to the same PowerShell process instance.

This is more reliable than correlating events only by timestamp, because unrelated activity can occur at the same time and Windows process IDs can eventually be reused.

## Timeline

```text
PowerShell.exe
  |
  |-- DNS Query -> example.com
  |       |
  |       +-> 172.66.147.243 / 104.20.23.154
  |
  |-- HTTPS Connection -> 172.66.147.243:443
  |
  +-- File Creation -> %TEMP%\soc-lab-test-final.txt
```

## Analyst Assessment

**Classification:** Benign / Authorized Lab Activity

The behavior was intentionally generated in a controlled lab environment. If the same sequence appeared unexpectedly on a production endpoint, it would warrant contextual investigation rather than immediate classification as malicious.

## Lessons Learned

1. Correlation matters more than reviewing isolated events.
2. PowerShell activity should be evaluated using command content, parent process, network behavior, and file activity together.
3. `ProcessGuid` is a useful pivot for Sysmon investigations.
4. Collection configuration directly affects investigative visibility.
5. Missing telemetry can be caused by filtering rules rather than absence of activity.
